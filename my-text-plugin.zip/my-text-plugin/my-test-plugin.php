<?php
/**
 * Plugin Name: My Test Plugin
 * Description: This is a test plugin for update testing.
 * Version: 1.0
 * Author: Your Name
 */

echo 'My Test Plugin is active.';
